#!/usr/bin/env node
import { chromium } from "playwright";
const base = "http://127.0.0.1:8080";
const browser = await chromium.launch({ headless: true });
const page = await browser.newPage({ viewport: { width: 1280, height: 800 } });
page.setDefaultTimeout(20000);
await page.goto(`${base}/home`, { waitUntil: "domcontentloaded" });
try {
  await page.getByRole("link", { name: "Clients" }).click();
  await page.getByRole("button", { name: "Add Client" }).click();
  await page.getByRole("button", { name: "Enter details manually" }).click();
  await page.getByLabel("Name").fill("Retry Lab");
  await page.getByRole("button", { name: "Save client" }).click();
  await page.getByText("Retry Lab").first().waitFor({ timeout: 20000 });
  await page.getByRole("link", { name: "Thumbnails" }).click();
  await page.getByRole("button", { name: "Select client" }).click();
  await page.getByRole("option", { name: "Retry Lab" }).first().click();
  await page.getByPlaceholder("Describe a thumbnail or paste a video topic...").fill("Close-up face, yellow light, 16:9 thumbnail, two words WAKE UP");
  await page.getByRole("button", { name: "Send" }).click();
  await page.waitForTimeout(80000);
  await page.screenshot({ path: "/workspace/screenshots/qa-thumbnails-retry.png", fullPage: true });
  console.log("done", page.url());
  const failed = await page.getByText("The image didn’t come through.").count();
  const imgs = await page.locator("img[alt]").count();
  console.log({ failed, imgs });
} catch (error) {
  console.error("QA failed", error);
  process.exit(1);
} finally {
  await browser.close();
}
